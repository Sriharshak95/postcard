import React from 'react';
import './customSpinner.css';

const CustomSpinner:React.FC = () => {
  return <div className="spinner"></div>;
}

export default CustomSpinner;
