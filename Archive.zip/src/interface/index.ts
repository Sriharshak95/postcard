export interface CardHeaderInterface {
  userDetails?: {
    name: string;
    email: string;
    picture: string;
  };
}
